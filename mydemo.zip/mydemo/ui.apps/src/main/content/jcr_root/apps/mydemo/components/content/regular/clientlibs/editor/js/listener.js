(function ($, $document) {
    "use strict";
    $(document).on("click", ".cq-dialog-submit", function (e) {
        $('.unique-tab-count').each(function(index){
            var tabCount = $(this).val();

            if(!tabCount){ //if tab count not generated previously
                tabCount = 'unique-id';// generate & assign unique id here
                $(this).val(tabCount);
            }
        });
    });
})($, $(document));