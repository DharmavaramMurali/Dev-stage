/* global jQuery, Coral */
(function($, Coral) {
    "use strict";

    console.log(" --------CLIENTLIBS LOADED------- ");

    var registry = $(window).adaptTo("foundation-registry");

    registry.register("foundation.validation.validator", {
            selector: "[data-validation=mydemo-email-validation]",
            validate: function(element) {
                let el = $(element);
                let pattern=/[0-9a-z]/;
                let value=el.val();
                if(!pattern.test(value)){
                   return "Invalid Email Please enter Valid Email !";
                }

            }

          });
          registry.register("foundation.validation.validator", {
                      selector: "[data-validation=mydemo-firstname-validation]",
                      validate: function(element1) {
                          let el = $(element1);
                          let pattern=/[0-9a-z]/;
                          let value=el.val();
                          if(pattern.test(value)){
                             return "Invalid Firstname";
                          }

                      }

                    });

 })(jQuery, Coral);
