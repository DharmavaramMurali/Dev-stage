package com.sutrix.demo.core.models.mobile;

import java.awt.*;
import java.util.List;

public interface Mobile {

    String getImages();

    String getMobileName();

    String getMobileModel();

    String getPrice();

    String getFeatures();

    String getLink();

//    List<String> getUser();


}
