package com.sutrix.demo.core.models.brand.config;

public interface BrandConfiguration {

    public String MobileStoreUrl();

    public String JayasreeUrl();

    public String NandhaGopalUrl();
}
