package com.sutrix.demo.core.bean;

/**
 * This class uses to save chidren items.
 *
 */
public class NestedMultifieldChildBean {

  private String childTitle;
  private String childDescription;

  /**
   * @return the childTitle
   */
  public String getChildTitle() {
    return childTitle;
  }

  /**
   * @param childTitle the childTitle to set
   */
  public void setChildTitle(String childTitle) {
    this.childTitle = childTitle;
  }

  /**
   * @return the childDescription
   */
  public String getChildDescription() {
    return childDescription;
  }

  /**
   * @param childDescription the childDescription to set
   */
  public void setChildDescription(String childDescription) {
    this.childDescription = childDescription;
  }

}
