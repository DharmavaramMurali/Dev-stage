package com.sutrix.demo.core.models.user;

public interface User {

    String getFirstName();

    String getLastName();

    String getCompanyName();

    String getArea();


}
