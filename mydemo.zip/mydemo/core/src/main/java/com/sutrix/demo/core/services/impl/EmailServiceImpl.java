package com.sutrix.demo.core.services.impl;

import com.sutrix.demo.core.services.EmailService;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailServiceImpl implements EmailService {

    private Pattern regexPattern;
    private Matcher regMatcher;

    String email = "dharmavarammurali13@gmail.com";
    @Override
    public boolean isValidEmail(String email) {


            regexPattern = Pattern.compile("^[(a-zA-Z-0-9-\\_\\+\\.)]+@[(a-z-A-z)]+\\.[(a-zA-z)]{2,3}$");
            regMatcher   = regexPattern.matcher(email);
            if(regMatcher.matches()) {
                return true;
            } else {
                return false;
            }
        }
    }

