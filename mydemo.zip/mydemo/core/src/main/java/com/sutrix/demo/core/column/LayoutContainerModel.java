package com.sutrix.demo.core.column;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;

/*
 * The Layout Container Model Class
 */
@Model(adaptables = {SlingHttpServletRequest.class, Resource.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class LayoutContainerModel extends CommonTabModel {
    private static final String OFFSET_TYPE_1 = "col-md-10 offset-md-1";
    private static final String OFFSET_TYPE_2 = "col-md-8 offset-md-2";

    /** The layout type */
    @ChildResource
    private String layoutType;

    /** The offset of layout */
    @ChildResource
    private String offset;

    /** The background color */
    @ChildResource
    private String backgroundColor;

    /** The inner background color */
    @ChildResource
    private String innerBackgroundColor;

    /** The padding left and right */
    @ChildResource
    private String paddinglr;

    /** The padding top and bottom */
    @ChildResource
    private String paddingtb;

    /** The border color */
    @ChildResource
    private String borderColor;

    /** The margin bottom */
    @ChildResource
    private String marginb;

    /** The noPadding */
    @ChildResource
    private Boolean noPadding;

    @ChildResource
    @Default(values = "0")
    private String shrinkedHeight;

    @ChildResource
    @Default(values = "")
    private String shrinkedBackgroundColor;

    /**
     * Get layout type.
     *
     * @return the layoutType
     */
    public String getLayoutType() {
        return layoutType;
    }

    /**
     * Get the background color
     *
     * @return the backgroundColor
     */
    public String getBackgroundColor() {
        return backgroundColor;
    }

    /**
     * Get the offset
     *
     * @return the offset
     */
    public String getOffset() {
        if (offset.equals("1")) {
            offset = OFFSET_TYPE_1;
        } else {
            offset = OFFSET_TYPE_2;
        }
        return offset;
    }


    /**
     * Get the inner background color
     *
     * @return the innerBackgroundColor
     */
    public String getInnerBackgroundColor() {
        return innerBackgroundColor;
    }

    /**
     * Get the padding left and right
     *
     * @return the paddinglr
     */
    public String getPaddinglr() {
        return paddinglr;
    }

    /**
     * Get the padding top and bottom
     *
     * @return the paddingtb
     */
    public String getPaddingtb() {
        return paddingtb;
    }

    /**
     * Get the border color
     *
     * @return the borderColor
     */
    public String getBorderColor() {
        return borderColor;
    }

    /**
     * Get the margin bottom
     *
     * @return the marginb
     */
    public String getMarginb() {
        return marginb;
    }

    /**
     * Get the noPadding
     *
     * @return the noPadding
     */
    public Boolean getNoPadding() {
        return noPadding;
    }

    public String getShrinkedHeight() {
        return shrinkedHeight;
    }

    public String getShrinkedBackgroundColor() {
        return shrinkedBackgroundColor;
    }
}
