package com.sutrix.demo.core.models.features.details;

import java.util.List;

public interface Details {

    String getMobile();

    String getModel();

    String getPrice();

    String getProcessor();

    String getRearCamera();

    String getSimType();

    String getBatteryCapacity();

    String getWarrenty();

    List<String> getRam();

    List<String> getRom();
}
