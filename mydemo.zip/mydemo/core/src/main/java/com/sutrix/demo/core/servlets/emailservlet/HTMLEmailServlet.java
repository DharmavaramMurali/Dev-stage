package com.sutrix.demo.core.servlets.emailservlet;

import com.day.cq.mailer.MessageGateway;
import com.day.cq.mailer.MessageGatewayService;
import com.sutrix.demo.core.services.EmailService;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component(service = Servlet.class, immediate = true,
        property = {
                "sling.servlet.methods=POST",
                "sling.servlet.paths=/mydemo/component/email/sender"
        })
public class HTMLEmailServlet extends SlingAllMethodsServlet {

    private static final long serialVersionUID = -7287396217733304212L;

    @Reference
    MessageGatewayService messageGatewayService;

//    @Reference
//    EmailMain emailMain;

//  @Reference
//  EmailService emailService;

    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        try {

            response.setContentType("text/html;charset-UTF-8");
            PrintWriter out = response.getWriter();

            String FirstName = request.getParameter("firstName");
            String Lastname = request.getParameter("lastName");
            String Email = request.getParameter("email");
            String Message = request.getParameter("message");


           if (messageGatewayService != null) {
               MessageGateway<HtmlEmail> gateway = messageGatewayService.getGateway(HtmlEmail.class);

               HtmlEmail htmlEmail = new HtmlEmail();
               htmlEmail.setFrom("no.information@gmail.com");
               htmlEmail.addTo(Email);
               htmlEmail.setSubject("Welcome To Sutrix Solutions ");
               htmlEmail.setContent(Message, "text/html");
               gateway.send(htmlEmail);

           }


              response.getWriter().write("Email Sent Successfully done to " + FirstName + "" + Lastname);

        } catch (EmailException e) {
        }
    }
}