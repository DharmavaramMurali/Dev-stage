//package com.sutrix.demo.core.email.mail;
//
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//
//public class EmailValidation {
//
//   public static String ValidEmail(String email) {
//       if (email == null || email.isEmpty()){
//           return "Invalid";
//       }
//       String emailregex =
//   }
//}