package com.sutrix.demo.core.services.impl;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.sutrix.demo.core.services.ResourceResolverService;
import com.sutrix.demo.core.services.SearchService;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.day.cq.wcm.api.NameConstants.NT_PAGE;
import static com.sutrix.demo.core.constants.AppConstants.*;

@Component(
        service = SearchService.class,
        property = {
                Constants.SERVICE_ID + EQUALS + SERVICE_NAME,
                Constants.SERVICE_DESCRIPTION + EQUALS + SERVICE_DESCRIPTION
        }
)
public class SearchServiceImpl implements SearchService {

    protected static final String SERVICE_NAME = "Search Service";
    protected static final String SERVICE_DESCRIPTION = "This services uses QueryBuilder API to search in JCR";

    private static final String TAG = SearchServiceImpl.class.getSimpleName();
    private static final Logger LOGGER = LoggerFactory.getLogger(SearchServiceImpl.class);

    @Reference
    QueryBuilder queryBuilder;

    @Reference
    ResourceResolverService resourceResolverService;

    @Override
    public List<String> searchByKeyword(String keyword) {
        LOGGER.debug("{}: trying to search for keyword: {}", TAG, keyword);
        // List of all the results
        List<String> resultPaths = new ArrayList<>();
        try {
            // Getting the instance of Resource Resolver
            ResourceResolver resourceResolver = resourceResolverService.getResourceResolver();
            // Adapting this resource resolver to get JCR session
            Session session = resourceResolver.adaptTo(Session.class);
            // Creating the predicates for the query using a map object
            Map<String, String> predicates = new HashMap<>();
            predicates.put("type", NT_PAGE);
            predicates.put("path", "/content/");
            predicates.put("fulltext", keyword);
            // Creating the query instance
            Query query = queryBuilder.createQuery(PredicateGroup.create(predicates), session);
            // Getting the results
            SearchResult searchResult = query.getResult();
            LOGGER.info("{}: number of results returned: {}", TAG, searchResult.getHits().size());
            // Loop through all the results
            for (Hit hit : searchResult.getHits()) {
                resultPaths.add(hit.getPath());
            }
        } catch (RepositoryException e) {
            LOGGER.error("{}: cannot search due to: {}", TAG, e.getMessage());
        }
        return resultPaths;
    }
}
















//    /*private static final Logger LOG= LoggerFactory.getLogger(SearchServiceImpl.class);
//
//    @Reference
//    QueryBuilder queryBuilder;
//
//    @Reference
//    ResourceResolverFactory resourceResolverFactory;
//
//    @Activate
//    public void activate(){
//        LOG.info("\n ----ACTIVATE METHOD----");
//    }
//
//    public Map<String,String> createTextSearchQuery(String searchText){
//        Map<String,String> queryMap=new HashMap<>();
//        queryMap.put("path","/content/mydemo");
//        queryMap.put("type", "cq:Page");
//        queryMap.put("fulltext",searchText);
//        queryMap.put("p.limit",Long.toString(-1));
//        return queryMap;
//    }
//
//    @Override
//    public JSONObject searchResult(String searchText, int startResult, int resultPerPage){
//        JSONObject searchResult=new JSONObject();
//        try {
//            ResourceResolver resourceResolver = ResolverUtil.newResolver(resourceResolverFactory);
//            final Session session = resourceResolver.adaptTo(Session.class);
//
//            Query query = queryBuilder.createQuery(PredicateGroup.create(createTextSearchQuery(searchText)), session);
//
//
//            SearchResult result = query.getResult();
//
//           List<Hit> hits =result.getHits();
//            JSONArray resultArray=new JSONArray();
//            for(Hit hit: hits){
//                Page page=hit.getResource().adaptTo(Page.class);
//                JSONObject resultObject=new JSONObject();
//                resultObject.put("title",page.getTitle());
//                resultObject.put("path",page.getPath());
//                resultArray.put(resultObject);
//                LOG.info("\n Page {} ",page.getPath());
//            }
//            searchResult.put("results",resultArray);
//
//        }catch (Exception e){
//            LOG.info("\n ----ERROR -----{} ",e.getMessage());
//        }
//        return searchResult;
//    }
//}
//*/