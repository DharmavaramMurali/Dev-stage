package com.sutrix.demo.core.dropdown;

import javax.annotation.PostConstruct;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.sling.api.resource.Resource;

import org.apache.sling.api.SlingHttpServletRequest;

import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;

import org.apache.sling.models.annotations.injectorspecific.SlingObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = SlingHttpServletRequest.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DropDownModel {

    private static final Logger log = LoggerFactory.getLogger(DropDownModel.class);

    @SlingObject
    private Resource componentResource;     //Used to get the current resource of the component

    private List<Map<String, String>> employeedetails = new ArrayList<>();

    public List<Map<String, String>> getMultiDataMap() {

        return employeedetails;

    }

    @PostConstruct
    protected void init() {

        Resource supportPoints = componentResource.getChild("employeedetails");  //now we will get the listregulars resource which holds the data in different item node.
        if (supportPoints != null) {
            for (Resource supportPoint : supportPoints.getChildren()) {

                Map<String, String> ListRegularMap = new HashMap<>();


                // Saving the property into a map, which will be fetched in HTML.
                ListRegularMap.put("employeeid",
                        supportPoint.getValueMap().get("employeeid", String.class));

                ListRegularMap.put("employeename",
                        supportPoint.getValueMap().get("employeename", String.class));

                ListRegularMap.put("mobileno",
                        supportPoint.getValueMap().get("mobileno", String.class));


                employeedetails.add(ListRegularMap);
            }
        }

    }

}
