package com.sutrix.demo.core.servlets.cust;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sutrix.demo.core.bean.Customer;
import org.json.JSONObject;
import javax.servlet.http.HttpServlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

    @WebServlet("/bin/cust")
    public class CustomerInformationServlet extends HttpServlet {

        private static final long serialVersionUID = 1L;

        private static final ObjectMapper objectMapper = new ObjectMapper();

        static {
            objectMapper.disable(DeserializationFeature.
                    FAIL_ON_UNKNOWN_PROPERTIES);
            objectMapper.configure(DeserializationFeature.
                    ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        }

        @Override
        protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

            List<Customer> cust = new ArrayList<>();
            for(Customer custom : cust){

                String customerid = custom.getCustomerid();
                String customername = custom.getCustomername();
                String customerage = custom.getCustomerage();
                String customergender = custom.getCustomergender();
            }


            String firstName = req.getParameter("firstName");
            String lastName = req.getParameter("lastName");
            String emailId = req.getParameter("emailId");
            String password = req.getParameter("password");

            resp.setContentType("application/json; charset=UTF-8");
            resp.getWriter().write(objectMapper.writeValueAsString(cust));

            System.out.println("customerid :: " + firstName);
            System.out.println("customerName :: " + lastName);
            System.out.println("customerage:: " + emailId);
            System.out.println("customergender :: " + password);
        }
    }