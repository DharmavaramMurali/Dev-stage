package com.sutrix.demo.core.models.login;

public interface Login {

    public String getUserName();

    public String getPassword();

    public String getEmail();
}
