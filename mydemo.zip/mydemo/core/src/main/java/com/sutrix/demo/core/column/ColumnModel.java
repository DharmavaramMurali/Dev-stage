package com.sutrix.demo.core.column;

import java.util.List;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;

/**
 * The Column Model Class
 */
@Model(adaptables = {SlingHttpServletRequest.class, Resource.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ColumnModel extends CommonTabModel {

    /** The list of column items */
    @ChildResource
    private List<ColumnItemsModel> items;

    /** The space between columns */
    @ChildResource
    private String spacing;

    /**
     * Get list of column items
     *
     * @return the items
     */
    public List<ColumnItemsModel> getItems() {
        return items;
    }

    /**
     * Get the spacing
     *
     * @return the spacing
     */
    public String getSpacing() {
        return spacing;
    }

}
