package com.sutrix.demo.core.services;

public interface EmailService {
    public boolean isValidEmail(String Email);

}
