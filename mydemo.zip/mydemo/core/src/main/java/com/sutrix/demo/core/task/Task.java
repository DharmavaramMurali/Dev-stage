package com.sutrix.demo.core.task;

public interface Task {

    public  String getTitle();

    public  String getDescription();
}
