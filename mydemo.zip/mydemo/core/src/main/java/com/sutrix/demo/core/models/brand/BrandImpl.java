package com.sutrix.demo.core.models.brand;


import com.day.cq.wcm.api.Page;
import com.sutrix.demo.core.models.brand.config.BrandConfiguration;
import com.sutrix.demo.core.models.mobile.Mobile;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.ResourcePath;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;


@Model(adaptables = {Resource.class, SlingAllMethodsServlet.class},
        adapters = Brand.class,
         defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

public class BrandImpl implements Brand {

    @Inject
    public  BrandConfiguration brandConfiguration;

    @SlingObject
    ResourceResolver resourceResolver;

    @ScriptVariable
    Page currentPage;

    @Inject
    private String images;

   @ValueMapValue
    private String brand;


    @ValueMapValue
    private String link;

    @ValueMapValue
    private String store;


    @Override
    public String getImages() { return images;}

    @Override
    public String getBrand() {
        return brand;
    }

    @Override
    public String getLink() { return link;}

    @Override
    public String getStore() { return store; }


}
