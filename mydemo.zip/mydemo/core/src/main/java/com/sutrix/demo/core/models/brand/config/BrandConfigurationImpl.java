package com.sutrix.demo.core.models.brand.config;


import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

/**
 * Component Configuration Implementation
 */
@Component(service = BrandConfiguration.class,
            immediate = true)

@Designate(ocd = BrandConfigurationImpl.Configuaration.class)
public class BrandConfigurationImpl implements BrandConfiguration {


    private String MobilStoreUrl;

    private String JayasreeUrl;

    private String NandhaGopalUrl;

    @Activate
    @Modified
    public void activate(Configuaration config) {
        this.MobilStoreUrl = config.getMobileStoreUrl();
    }

    @ObjectClassDefinition(name = "Mobile Store Configuration ")
    public @interface Configuaration {

        @AttributeDefinition(name = "Mobile Store Url",
                description = "Enter a Url for mobile store",
                type = AttributeType.STRING)
        public String getMobileStoreUrl();


        @AttributeDefinition(name = "Jayasree URL",
                description = "enter url",
                type = AttributeType.STRING)
        public String getJayasreeUrl();

        @AttributeDefinition(name = " NandhaGopalUrl URL",
                description = "enter url",
                type = AttributeType.STRING)
        public String[] getNandhaGopalUrl();

    }


    @Override
    public String MobileStoreUrl() {
        return MobilStoreUrl;
    }

    @Override
    public String JayasreeUrl() {
        return JayasreeUrl;
    }

    @Override
    public String NandhaGopalUrl() {
        return NandhaGopalUrl;
    }


}
