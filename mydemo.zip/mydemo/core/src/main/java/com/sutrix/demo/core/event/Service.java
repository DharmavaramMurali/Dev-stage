package com.sutrix.demo.core.event;

public @interface Service {
}
