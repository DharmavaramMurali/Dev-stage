package com.sutrix.demo.core.pojo;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sutrix.demo.core.bean.NestedMultifieldBean;

/**
 * This class uses to handle the Nested Multifield Component.
 */
public class NestedMultifieldComponent extends WCMUsePojo {

  private static final Logger LOGGER = LoggerFactory.getLogger(NestedMultifieldComponent.class);

  private static final String MAIN_ITEM_NAME = "mainItems";
  private List<NestedMultifieldBean> nestedMultifieldItems;


  @Override
  public void activate() throws Exception {
    try {

      // Get List Navigation Menu
      String[] mainItems = getProperties().get(MAIN_ITEM_NAME, String[].class);
      if (ArrayUtils.isEmpty(mainItems)) {
        return;
      }

      ObjectMapper mapper = new ObjectMapper();
      nestedMultifieldItems = new ArrayList<>();

      for (String mainItem : mainItems) {
        NestedMultifieldBean nestedMultifieldBean =
            mapper.readValue(mainItem, NestedMultifieldBean.class);
        if (null != nestedMultifieldBean) {
          nestedMultifieldItems.add(nestedMultifieldBean);
        }
      }
    } catch (Exception e) {
      LOGGER.error("error in getting item of Nested Multifield Component", e);
    }
  }

  public List<NestedMultifieldBean> getNestedMultifieldItems() {
    return nestedMultifieldItems;
  }

}
