package com.sutrix.demo.core.email.mail;

import com.sutrix.demo.core.services.EmailService;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.osgi.service.component.annotations.Reference;



public class EmailMain {

    @Reference
    EmailService emailService;

    private String Email;

    public EmailMain() {
    }


    public String getEmail() {
       boolean valid = emailService.isValidEmail(Email);
       if (valid == true) {
           return "valid email";
       }return null;
    }

    public void setEmail(String email) {
        Email = email;
    }

}
