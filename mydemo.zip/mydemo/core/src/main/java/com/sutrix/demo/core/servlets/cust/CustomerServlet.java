package com.sutrix.demo.core.servlets.cust;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.Servlet;

import com.google.gson.*;
import com.sutrix.demo.core.bean.Customer;
import org.apache.commons.io.IOUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import static com.adobe.granite.activitystreams.Verbs.TAG;
import static com.sutrix.demo.core.constants.AppConstants.NEW_LINE;

@Component(service = Servlet.class,
           property = {
                       Constants.SERVICE_DESCRIPTION + "=Customer Info Servlet",
                       "sling.servlet.methods=" + HttpConstants.METHOD_GET,
                       "sling.servlet.methods=" + HttpConstants.METHOD_POST,
                       "sling.servlet.extension= json",
                       "sling.servlet.paths=" + "/bin/customer/information/status"
})
public class CustomerServlet extends SlingAllMethodsServlet {


    private static final long serialVersionUID = -7434298269108323345L;
    private static final Logger LOG = LoggerFactory.getLogger(CustomerServlet.class);

    private static final ObjectMapper objectMapper = new ObjectMapper();

    static {
        objectMapper.disable(DeserializationFeature.
                FAIL_ON_UNKNOWN_PROPERTIES);
        objectMapper.configure(DeserializationFeature.
                ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
    }

    @Override
    public void doGet(SlingHttpServletRequest request,
                      SlingHttpServletResponse response) throws IOException {

        try {

            List<Customer> customers = new ArrayList<>();

            customers.add(new Customer("01", "Jayasri", "23", "Female"));
            customers.add(new Customer("02", "Jayasree", "22", "Female"));

            response.setContentType("application/json; charset=UTF-8");
            response.getWriter().write(objectMapper.writeValueAsString(customers));

        } catch (Exception ex) {
            LOG.error("error in Customer Information", ex);
        }
    }

    @Override
    public void doPost(SlingHttpServletRequest request,
                       SlingHttpServletResponse response) throws IOException {


        try {

            List<Customer> cust = new ArrayList<>();
            for (Customer custom : cust) {
                String result = IOUtils.toString(request.getReader());
                JsonElement outputJSON = new JsonParser().parse(result);
                if (outputJSON.isJsonArray()) {
                    JsonArray jsonArray = outputJSON.getAsJsonArray();

                    custom.getCustomerid();
                    custom.getCustomername();
                    custom.getCustomerage();
                    custom.getCustomergender();

                    response.setContentType("application/json; charset=UTF-8");
                    response.getWriter().write(objectMapper.writeValueAsString(cust));
                }

            }
        } catch (Exception e) {
            LOG.info("\n ERROR IN REQUEST {} ", e.getMessage());
        }
        //response.getWriter().write("Customer Information Successfully Executed");
    }
    }



























// List<Customer> cust = new ArrayList<>();

// for(Customer custom : cust)


//                LOG.info("\n CUSTOMERID  {} : {} ", custom.getCustomerid());
//                        LOG.info("\n CUSTOMERNAME  {} : {} ", custom.getCustomername());
//                        LOG.info("\n CUSTOMERAGE  {} : {} ", custom.getCustomerage());
//                        LOG.info("\n CUSTOMEGENDER  {} : {} ", custom.getCustomergender());
