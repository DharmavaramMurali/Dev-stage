package com.sutrix.demo.core.models.pojonav;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.sling.api.resource.ResourceResolver;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.commons.inherit.HierarchyNodeInheritanceValueMap;
import com.day.cq.commons.inherit.InheritanceValueMap;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.sutrix.demo.core.bean.MenuItem;

/**
 * This is to use to get all menu items.
 */
public class NavigationComponent extends WCMUsePojo {

  private static final String ROOT_PATH_FIELD = "rootPath";
  private static final String ROOT_PATH_DEFAULT = "/content/mydemo/en";

  List<MenuItem> menuItems = null;

  @Override
  public void activate() throws Exception {
    InheritanceValueMap properties = new HierarchyNodeInheritanceValueMap(getResource());
    String rootPath = properties.getInherited(ROOT_PATH_FIELD, String.class);

    if (null == rootPath || "".equals(rootPath)) {
      rootPath = ROOT_PATH_DEFAULT;
    }

    Page rootPage = getPage(rootPath);
    if (rootPage == null) {
      return;
    }

    menuItems = new ArrayList<>();
    menuItems.add(new MenuItem(getTitle(rootPage), rootPage.getPath()));

    Iterator<Page> children = rootPage.listChildren();
    while (children.hasNext()) {
      Page page = children.next();
      if (page != null) {
        MenuItem menuItem = new MenuItem(getTitle(page), page.getPath());
        List<MenuItem> childItems = getChildren(page);
        if (!childItems.isEmpty()) {
          menuItem.setChildren(childItems);
        }
        menuItems.add(menuItem);
      }
    }
  }

  /**
   * Gets page by {@code pagePath}
   * 
   * @param pagePath the path of page
   * @return a {@link Page}
   */
  private Page getPage(String pagePath) {
    Page page = null;
    if (null == getRequest()) {
      return page;
    }

    ResourceResolver resolver = getRequest().getResourceResolver();
    if (pagePath.startsWith("/")) {
      PageManager pageManager = resolver.adaptTo(PageManager.class);
      if (pageManager != null) {
        page = pageManager.getContainingPage(pagePath);
      }
    }
    return page;
  }

  /**
   * Gets all child pages by {@link Page}.
   * 
   * @param page a parent page.
   * @return list of {@link MenuItem} if found. Otherwise return {@code null}.
   */
  private List<MenuItem> getChildren(Page page) {

    List<MenuItem> childItems = new ArrayList<>();
    Iterator<Page> children = page != null ? page.listChildren() : null;
    if (children == null || !children.hasNext()) {
      return childItems;
    }

    while (children.hasNext()) {
      Page childPage = children.next();
      if (childPage != null) {
        childItems.add(new MenuItem(getTitle(childPage), childPage.getPath()));
      }
    }

    return childItems;
  }

  /**
   * Gets page title by {@link Page}
   * 
   * @param page a {@link Page}
   * @return the title of page.
   */
  private String getTitle(Page page) {
    String title = "";
    if (page == null) {
      return title;
    }

    title = page.getTitle();
    if ("".equals(title)) {
      title = page.getPageTitle();
      if ("".equals(title)) {
        title = page.getNavigationTitle();
        if ("".equals(title)) {
          title = page.getName();
        }
      }
    }

    return title;
  }

  /**
   * @return the menuItems
   */
  public List<MenuItem> getMenuItems() {
    return menuItems;
  }

}
