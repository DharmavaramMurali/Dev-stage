package com.sutrix.demo.core.bean;

import java.util.List;

/**
 * This class is to define attributes of the Nested Multifield component.
 */
public class NestedMultifieldBean {
  private String title;
  private String description;
  private List<NestedMultifieldChildBean> childItems;

  /**
   * @return the title
   */
  public String getTitle() {
    return title;
  }

  /**
   * @param title the title to set
   */
  public void setTitle(String title) {
    this.title = title;
  }

  /**
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * @param description the description to set
   */
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * @return the childItems
   */
  public List<NestedMultifieldChildBean> getChildItems() {
    return childItems;
  }

  /**
   * @param childItems the childItems to set
   */
  public void setChildItems(List<NestedMultifieldChildBean> childItems) {
    this.childItems = childItems;
  }

}
