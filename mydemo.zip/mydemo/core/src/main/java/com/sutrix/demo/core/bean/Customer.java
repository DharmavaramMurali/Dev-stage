package com.sutrix.demo.core.bean;

public class Customer {

    private String customerid;

    private String customername;

    private String customerage;

    private String customergender;


    public Customer() {
    }

    public Customer(String customerid, String customername, String customerage, String customergender) {
        this.customerid = customerid;
        this.customername = customername;
        this.customerage = customerage;
        this.customergender = customergender;
    }

    public String getCustomerid() { return customerid; }

    public void setCustomerid(String customerid) { this.customerid = customerid;}

    public String getCustomername() { return customername; }

    public void setCustomername(String customername) { this.customername = customername; }

    public String getCustomerage() { return customerage; }

    public void setCustomerage(String customerage) { this.customerage = customerage; }

    public String getCustomergender() { return customergender; }

    public void setCustomergender(String customergender) { this.customergender = customergender; }


    @Override
    public String toString() {
        return "Customer{" +
                "customerid='" + customerid + '\'' +
                ", customername='" + customername + '\'' +
                ", customerage='" + customerage + '\'' +
                ", customergender='" + customergender + '\'' +
                '}';
    }


}
