package com.sutrix.demo.core.models.features;


import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Model(adaptables = Resource.class,
       adapters = Features.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

public class FeaturesImpl implements Features {

    @Inject
    private String image;

    @Inject
    private String mobile;

    @Inject
    private String model;

    @Inject
    private String price ;

    @Inject
    private String processor;

    @Inject
    private String rearcamera;

    @Inject
    private String simtype;

    @Inject
    private String batterycapacity;

    @Inject
    private String warrenty;

    @ValueMapValue
    private List<String> ram;

    @ValueMapValue
    private List<String> rom;

    @Override
    public String getImage() {
        return image;
    }

    @Override
    public String getMobile() {
        return mobile;
    }

    @Override
    public String getModel() {
        return model;
    }

    @Override
    public String getPrice() {
        return price;
    }

    @Override
    public String getProcessor() {
        return processor;
    }

    @Override
    public String getRearCamera() {
        return rearcamera;
    }

    @Override
    public String getSimType() {
        return simtype;
    }

    @Override
    public String getBatteryCapacity() {
        return batterycapacity;
    }

    @Override
    public String getWarrenty() {
        return warrenty;
    }

    @Override
    public List<String> getRam() {
        if (ram==null){
            return new ArrayList<String>(ram);
        } else {
            return Collections.emptyList();
        }
    }

    @Override
    public List<String> getRom() {
        if (rom!=null){
            return new ArrayList<String>(rom);
        } else {
            return Collections.emptyList();
        }
    }
}
