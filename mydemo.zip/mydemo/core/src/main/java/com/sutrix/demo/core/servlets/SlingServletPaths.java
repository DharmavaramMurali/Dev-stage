package com.sutrix.demo.core.servlets;

public @interface SlingServletPaths {
    String[] value();
}
