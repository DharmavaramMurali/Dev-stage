//package com.sutrix.demo.core.models.mobile;
//
//import org.apache.sling.api.resource.Resource;
//import org.apache.sling.models.annotations.Model;
//import org.apache.sling.models.annotations.Optional;
//
//import javax.inject.Inject;
//
//@Model(adaptables = Resource.class)
//public class Image {
//
//    // Inject the products node under the current node
//    /**
//     * The carousel items
//     */
//    @Inject
//    @Optional
//    public Resource imagepath;
//}
