package com.sutrix.demo.core.models.brand;

public interface Brand {


    String getImages();

    String getBrand();

    String getLink();

    String getStore();



}
