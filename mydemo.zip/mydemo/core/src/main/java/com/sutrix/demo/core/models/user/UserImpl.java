package com.sutrix.demo.core.models.user;



import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;



@Model(adaptables = {Resource.class, SlingAllMethodsServlet.class},
        adapters = User.class,
         defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class UserImpl implements User {

   @ValueMapValue
//   @Default(values = "MURALI")
    private String firstname;

    @ValueMapValue
//    @Default(values = "DHARMAVARAM")
    private String lastname;

    @ValueMapValue
//    @Default(values = "SUTRIX SOLUTIONS")
    private String companyname;

    @ValueMapValue
//    @Default(values = "CHENNAI")
    private String area;



    @Override
    public String getFirstName() {
        return firstname;
    }

    @Override
    public String getLastName() {
        return lastname;
    }

    @Override
    public String getCompanyName() {
        return companyname;
    }

    @Override
    public String getArea() {
        return area;
    }

}
