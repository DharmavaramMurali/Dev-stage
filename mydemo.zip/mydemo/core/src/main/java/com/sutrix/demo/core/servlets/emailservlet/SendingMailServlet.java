package com.sutrix.demo.core.servlets.emailservlet;


import com.day.cq.mailer.MessageGateway;
import com.day.cq.mailer.MessageGatewayService;
import com.sutrix.demo.core.email.sendtoauthor.osgiforemail.CQMailConfig;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import java.io.IOException;

@Component(service = Servlet.class, immediate = true,
            property = {
                         "sling.servlet.methods=GET",
                         "sling.servlet.paths=/mydemo/emailsenderservlet"
            })
public class SendingMailServlet extends SlingAllMethodsServlet {

    private static final long serialVersionUID = -7287396217733304212L;


    @Reference
    MessageGatewayService messageGatewayService;

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
           try{
               if (messageGatewayService!=null) {
                   MessageGateway<HtmlEmail> gateway = messageGatewayService.getGateway(HtmlEmail.class);

                   HtmlEmail htmlEmail = new HtmlEmail();
                   htmlEmail.setFrom("no.information@gmail.com");
                   htmlEmail.addTo("gopalnandha197@gmail.com");
                   htmlEmail.setSubject("Employee Detail's");
                   htmlEmail.setContent("Hi Team, <br/> Name : Dharmavaram Murali. <br/> Mobile No : 9100459554 <br/> Company : Sutrix Solutions <br/> Role :  JAVA INTERN <br/> Location : Chennai <br/>   Thanks and Regards,<br/>Dharmavaram Murali.", "text/html");
                   gateway.send(htmlEmail);
               }
               response.getWriter().write("Email Sent Successfully Done !");

            } catch (EmailException e) {
            }
        }
    }
