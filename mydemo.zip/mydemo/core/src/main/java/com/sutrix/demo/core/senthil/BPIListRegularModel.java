package com.sutrix.demo.core.senthil;

import com.adobe.cq.export.json.ExporterConstants;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;


import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Model(adaptables = { SlingHttpServletRequest.class,
		Resource.class }, resourceType = BPIListRegularModel.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, extensions = ExporterConstants.SLING_MODEL_EXTENSION)
public class BPIListRegularModel {

	public static final String RESOURCE_TYPE = "bpi/components/listregular";

	@ChildResource
	private String variation;

	private List<RegularModel> items;

	@SlingObject
	private Resource currentResource;

	@SlingObject
	private ResourceResolver resourceResolver;

	@PostConstruct
	protected void init() {
		//items = CommonUtil.parseMutilFieldFormResource(currentResource, "items", RegularModel.class, resourceResolver);
	}

	public List<RegularModel> getItems() {
		if (CollectionUtils.isEmpty(items)) {
			return Collections.emptyList();
		}
		//items.removeIf(item -> StringUtils.isBlank(item.getHeading()));
		return new ArrayList<>(items);
	}

	public String getVariation() {
		return variation;
	}
}
