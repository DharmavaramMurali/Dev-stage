package com.sutrix.demo.core.models.author;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.*;

@Model(adaptables = {Resource.class,SlingAllMethodsServlet.class},
        adapters = Author.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class AuthorImpl implements Author {

    private static final Logger LOG = LoggerFactory.getLogger(AuthorImpl.class);

    @SlingObject
    ResourceResolver resourceResolver;

    @Inject
    Resource componentResource;

//    @ScriptVariable
//    Page currentPage;

    @ValueMapValue
    private String firstname;

    @ValueMapValue
    private String lastname;
    @ValueMapValue
    private String companyname;

    @ValueMapValue
    private String email;

  @ValueMapValue
    private List<String> course;


    @Override
    public String getFirstName() { return firstname; }

    @Override
    public String getLastName() { return lastname; }

    @Override
    public String getCompanyName() { return companyname; }

    @Override
    public String getEmail() { return email; }

    ///////////MultiField with single property
    @Override
    public List<String> getCourse() {
        if (course != null) {
            return new ArrayList<String>(course);
        } else {
            return Collections.emptyList();
        }
    }

    ///////////MultiField with Multiple property

    @Override
    public List<Map<String, String>> getEmployeeDetails() {
        List<Map<String, String>> employeeDetailsMap=new ArrayList<>();
        try {
            Resource employeedetails = componentResource.getChild("employeedetails");
            if (employeedetails != null) {
                for (Resource employee : employeedetails.getChildren()) {
                    Map<String, String> employeeMap = new HashMap<>();

                    employeeMap.put("id", employee.getValueMap().get("id", String.class));
                    employeeMap.put("aadhaarno", employee.getValueMap().get("aadhaarno", String.class));
                    employeeMap.put("mobileno", employee.getValueMap().get("mobileno", String.class));
                    employeeMap.put("secretcode", employee.getValueMap().get("secretcode", String.class));
                    employeeDetailsMap.add(employeeMap);
                }
            }
        }catch (Exception e){
            LOG.info("\n ERROR while getting Employee Details", e.getMessage());
        }
        LOG.info("\n SIZE {}", employeeDetailsMap.size());
        return employeeDetailsMap;
    }

}





