package com.sutrix.demo.core.models.login;


import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import javax.inject.Inject;

@Model(adaptables = Resource.class,
        adapters = Login.class,
         defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class LoginImpl implements Login {

    @Inject
    private String username;

    @Inject
    private String password;

    @Inject String email;


    @Override
    public String getUserName() {
        return username;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getEmail() {
        return email;
    }
}
