package com.sutrix.demo.core.normaljavaclasses;

public class RandomNumbers{
    public static void main(String[] args) {

        Counter count = new Counter();

        Thread t = new Thread(new Runnable(){
            @Override
            public void run() {
                synchronized (count) {
                    for(int i=1;i<=50;i=i+2){
                        if(!count.isEven()){
                            try {
                                count.wait();
                            } catch (InterruptedException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                        }
                        System.out.println(i);
                        count.setEven(false);
                        count.notify();
                    }
                }

            }

        });

        Thread t1 = new Thread(new Runnable(){
            @Override
            public void run() {
                synchronized (count) {


                    for(int i=2;i<50;i=i+2){
                        if(count.isEven){
                            try {
                                count.wait();
                            } catch (InterruptedException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                        }
                        System.out.println(i);
                        count.setEven(true);
                        count.notify();
                    }
                }
            }
        });

        t.start();
        t1.start();

    }

    static class Counter {
        boolean isEven = true;

        public boolean isEven() {
            return isEven;
        }

        public void setEven(boolean isEven) {
            this.isEven = isEven;
        }

    }
}

