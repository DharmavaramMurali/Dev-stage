package com.sutrix.demo.core.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sutrix.demo.core.bean.District;

/**
 * Lists all districts.
 */
@Component(service = Servlet.class,
property = {
    "sling.servlet.methods=GET",
    "sling.servlet.paths=/bin/mydemo/districts"
})
public class DistrictServlet extends SlingAllMethodsServlet {

  private static final long serialVersionUID = -7434298269108323345L;

  private static final Logger LOGGER = LoggerFactory.getLogger(DistrictServlet.class);
  
  private static final ObjectMapper objectMapper = new ObjectMapper();
  static {
    objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
  }

  @Override
  public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
      throws IOException {

    try {
      
      List<District> districts = new ArrayList<>();
      
      districts.add(new District("01", "District 1"));
      districts.add(new District("02", "District 2"));
      

      response.setContentType("application/json; charset=UTF-8");
      response.getWriter().write(objectMapper.writeValueAsString(districts));

    } catch (Exception ex) {
      LOGGER.error("error in getting districts list", ex);
    }
  }
}
