package com.sutrix.demo.core.unittest;

public class MainClass {

    public static void main(String[] args){


        Calculator cl = new Calculator();

        System.out.println("Adding = "+cl.add(10,20));
        System.out.println("Subtraction = "+cl.subtract(40,50));
        System.out.println("Multiplication = "+cl.Multiplication(4,20));
        System.out.println("Division = "+cl.division(200,10));
    }
}
