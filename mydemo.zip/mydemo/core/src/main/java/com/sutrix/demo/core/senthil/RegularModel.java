package com.sutrix.demo.core.senthil;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
//import utils.LinkUtils;

import java.util.Objects;

@Model(adaptables = { SlingHttpServletRequest.class,
		Resource.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class RegularModel extends TwoColumnModel {

	@ChildResource
	private String icon;

	@ChildResource
	private String overline;

	@ChildResource
	private String heading;

	@ChildResource
	private String description;

	@ChildResource
	private String textLink;

	@SlingObject
	private ResourceResolver resourceResolver;

	public RegularModel(String icon, String overline, String heading, String description, String textLink) {
		this.icon = icon;
		this.overline = overline;
		this.heading = heading;
		this.description = description;
		this.textLink = textLink;
	}

	public RegularModel() {
	}

	public String getIcon() {
		return icon;
	}

	public String getOverline() {
		return overline;
	}

//	public String getTextLink() {
//		return LinkUtils.getProperURL(textLink, resourceResolver);
//	}
//
//	public String getTarget() {
//		return LinkUtils.isExternalUrl(textLink, resourceResolver) ? "_blank" : "_seft";
//	}

	public String getHeading() {
		return heading;
	}

	public String getDescription() { return description; }

}
