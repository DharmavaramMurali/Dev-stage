package com.sutrix.demo.core.unittest;

public class Calculator {

    public int add(int a,int b){
        return a+b;
    }

    public int subtract(int c, int d){
        return c-d;
    }

    public  int Multiplication(int e, int f){
        return e*f;
    }

    public int division(int g, int h){
        return g/h;
    }

}
