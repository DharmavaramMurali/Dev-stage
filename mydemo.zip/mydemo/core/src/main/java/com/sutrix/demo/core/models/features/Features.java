package com.sutrix.demo.core.models.features;

import java.util.List;

public interface Features {

    String getImage();

    String getMobile();

    String getModel();

    String getPrice();

    String getProcessor();

    String getRearCamera();

    String getSimType();

    String getBatteryCapacity();

    String getWarrenty();

    List<String> getRam();

    List<String> getRom();
}
