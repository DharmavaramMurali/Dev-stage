package com.sutrix.demo.core.models.author;

import java.util.List;
import java.util.Map;

public interface Author {

    String getFirstName();

    String getLastName();

    String getCompanyName();

    String getEmail();

    ////////Multifield with single property
    List<String> getCourse();

    ////////Multifield with multiple property

    List<Map<String,String>> getEmployeeDetails();

}
