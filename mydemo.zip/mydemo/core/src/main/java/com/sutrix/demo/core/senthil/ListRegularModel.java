package com.sutrix.demo.core.senthil;

import javax.annotation.PostConstruct;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.sling.api.resource.Resource;

import org.apache.sling.api.SlingHttpServletRequest;

import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;

import org.apache.sling.models.annotations.injectorspecific.SlingObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = SlingHttpServletRequest.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ListRegularModel {

    private static final Logger log = LoggerFactory.getLogger(ListRegularModel.class);

    @SlingObject
    private Resource componentResource;     //Used to get the current resource of the component

    private List<Map<String, String>> listregulars = new ArrayList<>();

    public List<Map<String, String>> getMultiDataMap() {

        return listregulars;

    }

    @PostConstruct
    protected void init() {

        Resource supportPoints = componentResource.getChild("listregulars");  //now we will get the listregulars resource which holds the data in different item node.
        if (supportPoints != null) {
            for (Resource supportPoint : supportPoints.getChildren()) {

                Map<String, String> ListRegularMap = new HashMap<>();


                // Saving the property into a map, which will be fetched in HTML.
                ListRegularMap.put("icon",
                        supportPoint.getValueMap().get("icon", String.class));
                ListRegularMap.put("overline",
                        supportPoint.getValueMap().get("overline", String.class));
                ListRegularMap.put("heading",
                        supportPoint.getValueMap().get("heading", String.class));
                ListRegularMap.put("description",
                        supportPoint.getValueMap().get("description", String.class));
                ListRegularMap.put("label",
                        supportPoint.getValueMap().get("label", String.class));
                ListRegularMap.put("value",
                        supportPoint.getValueMap().get("value", String.class));
                ListRegularMap.put("subvalue",
                        supportPoint.getValueMap().get("subvalue", String.class));

                listregulars.add(ListRegularMap);
            }
        }

    }

}
