package com.sutrix.demo.core.services;

import org.apache.sling.commons.json.JSONObject;

import java.util.List;

public interface SearchService {

    List<String> searchByKeyword(String keyword);

    //public JSONObject searchResult(String searchText, int startResult, int resultPerPage);
}
