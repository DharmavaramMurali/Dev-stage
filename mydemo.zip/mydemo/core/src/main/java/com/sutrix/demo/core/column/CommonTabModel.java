package com.sutrix.demo.core.column;

import org.apache.sling.models.annotations.injectorspecific.ChildResource;

public class CommonTabModel {

    @ChildResource
    private String componentId;

    @ChildResource
    private String componentClass;

    public String getComponentId() {
        return componentId;
    }

    public void setComponentId(String componentId) {
        this.componentId = componentId;
    }

    public String getComponentClass() {
        return componentClass;
    }

    public void setComponentClass(String componentClass) {
        this.componentClass = componentClass;
    }

}
