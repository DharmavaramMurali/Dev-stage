package com.sutrix.demo.core.models.features.details;


import com.day.cq.wcm.api.Page;
import com.sutrix.demo.core.models.mobile.MobileImpl;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.ResourcePath;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Model(adaptables = Resource.class,
       adapters = Details.class,
        resourceType = DetailsImpl.RESOURCE_TYPE,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = "jackson", extensions = {"json","txt","xml"}, selector ="smart")

public class DetailsImpl implements Details {


    private static final Logger LOG = LoggerFactory.getLogger(MobileImpl.class);

    static final String RESOURCE_TYPE = "mydemo/components/content/details";

    @SlingObject
    ResourceResolver resourceResolver;

    @ResourcePath(path= "/content/mydemo/en/features")
    @Via("resource")
    Resource resource;

    @ScriptVariable
    Page currentPage;

    @Inject
    private String mobile;

    @Inject
    private String model;

    @Inject
    private String price ;

    @Inject
    private String processor;

    @Inject
    private String rearcamera;

    @Inject
    private String simtype;

    @Inject
    private String batterycapacity;

    @Inject
    private String warrenty;

    @ValueMapValue
    private List<String> ram;

    @ValueMapValue
    private List<String> rom;

    @Override
    public String getMobile() {
        return mobile;
    }

    @Override
    public String getModel() {
        return model;
    }

    @Override
    public String getPrice() {
        return price;
    }

    @Override
    public String getProcessor() {
        return processor;
    }

    @Override
    public String getRearCamera() {
        return rearcamera;
    }

    @Override
    public String getSimType() {
        return simtype;
    }

    @Override
    public String getBatteryCapacity() {
        return batterycapacity;
    }

    @Override
    public String getWarrenty() {
        return warrenty;
    }

    @Override
    public List<String> getRam() {
        if (ram!=null){
            return new ArrayList<String>(ram);
        } else {
            return Collections.emptyList();
        }
    }

    @Override
    public List<String> getRom() {
        if (rom!=null){
            return new ArrayList<String>(rom);
        } else {
            return Collections.emptyList();
        }
    }
}
