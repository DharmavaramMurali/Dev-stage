package com.sutrix.demo.core.column;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

@Model(adaptables = Resource.class)
public class ColumnItemsModel {

    @Inject
    @Optional
    String pcColumnNumber;

    @Inject
    @Optional
    String spColumnNumber;

    @Inject
    @Optional
    String pcColumnTextAlign;

    @Inject
    @Optional
    String spColumnTextAlign;

    @Inject
    @Optional
    String borderColor;

    public String getPcColumnNumber() {
        return pcColumnNumber;
    }

    public void setPcColumnNumber(String pcColumnNumber) {
        this.pcColumnNumber = pcColumnNumber;
    }

    public String getSpColumnNumber() {
        return spColumnNumber;
    }

    public void setSpColumnNumber(String spColumnNumber) {
        this.spColumnNumber = spColumnNumber;
    }

    public String getPcColumnTextAlign() {
        return pcColumnTextAlign;
    }

    public String getSpColumnTextAlign() {
        return spColumnTextAlign;
    }

    public String getBorderColor() {
        return borderColor;
    }

}
