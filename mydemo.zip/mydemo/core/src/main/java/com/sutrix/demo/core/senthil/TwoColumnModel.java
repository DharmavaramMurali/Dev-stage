package com.sutrix.demo.core.senthil;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;


@Model(adaptables = { SlingHttpServletRequest.class,
		Resource.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public abstract class TwoColumnModel {

	@ChildResource
	protected String label;

	@ChildResource
	protected String value;

	@ChildResource
	protected String subvaleu;


	public String getLabel() {
		return label;
	}

	public String getValue() {
		return value;
	}

	public String getSubvaleu() {
		return subvaleu;
	}

	/*public String getTextLink() {
		return LinkUtils.getProperURL(textLink, resourceResolver);
	}*/

	/*public String getTarget() {
		return LinkUtils.isExternalUrl(textLink, resourceResolver) ? "_blank" : "_seft";
	}*/

}
