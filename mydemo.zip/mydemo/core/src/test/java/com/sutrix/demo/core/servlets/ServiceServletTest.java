//package com.sutrix.demo.core.servlets;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//
//@ExtendWith(AemContextExtension.class)
//class ServiceServletTest {
//
//    @BeforeEach
//    void setUp() {
//    }
//
//    @Test
//    void doGet() {
//    }
//}