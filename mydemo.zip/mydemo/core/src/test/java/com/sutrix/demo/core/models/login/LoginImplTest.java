package com.sutrix.demo.core.models.login;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LoginImplTest {

    LoginImpl login;

    @BeforeEach
    void setUp() {

        login = new LoginImpl();
    }

    @Test
    void getUserName() {

        String username="Murali";
        login.getUserName();

        assertEquals("Murali","Murali");
    }

    @Test
    void getPassword() {

        String password="Dharmavaram123";
        login.getPassword();

        assertEquals("Dharmavaram123","Dharmavaram123");
    }

    @Test
    void getEmail() {
    }
}