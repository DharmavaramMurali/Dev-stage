package com.sutrix.demo.core.models.features;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.junit.jupiter.api.Assertions.*;


//@ExtendWith(AemContextExtension.class)
class FeaturesImplTest {



    @BeforeEach
    void setUp() {
    }

    @Test
    void getImage() {
    }

    @Test
    void getMobile() {
    }

    @Test
    void getModel() {
    }

    @Test
    void getPrice() {
    }

    @Test
    void getProcessor() {
    }

    @Test
    void getRearCamera() {
    }

    @Test
    void getSimType() {
    }

    @Test
    void getBatteryCapacity() {
    }

    @Test
    void getWarrenty() {
    }

    @Test
    void getRam() {
    }

    @Test
    void getRom() {
    }
}